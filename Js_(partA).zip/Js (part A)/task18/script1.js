function sumTo(n){
    if (n == 1) return 1;
    return n + sunTo(n - 1);
}