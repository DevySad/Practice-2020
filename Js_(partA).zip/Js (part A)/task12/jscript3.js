var result = prompt("Кто пришел?", "");

if (result == "Админ"){ 
    var result2 = prompt("Пароль?", "");
    
    if (result2 == "Черный Властелин"){
        alert("Добро пожаловать!");
    }
    else if (result2 == null){
        alert("Вход отменен");
    }
    else 
        alert("Пароль неверен");
}
else if (result == null){
    alert("Вход отменен");
}
else
    alert("Я вас не знаю");