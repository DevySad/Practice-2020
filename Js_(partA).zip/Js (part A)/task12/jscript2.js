var res = prompt("", "");

if (res > 0) 
    alert("1");
else if (res < 0)
    alert("-1");
else
    alert("0");