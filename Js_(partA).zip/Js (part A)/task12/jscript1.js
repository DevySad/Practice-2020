if (prompt("Каково официальное название JavaScript?", "") == "ECMAScript")
    alert("Верно!");
else
    alert("Не знаете? ECMAScript!");