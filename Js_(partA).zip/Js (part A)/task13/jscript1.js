var age = 14;

if (age >= 14 && age <= 90)
    alert(true);