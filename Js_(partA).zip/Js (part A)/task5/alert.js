var admin, name;
name = "Василий";
admin = name;
alert(admin);