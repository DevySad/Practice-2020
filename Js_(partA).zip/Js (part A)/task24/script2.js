function checkSpam(str){
    return !!(~lowerStr.indexOf('viagra') || ~lowerStr.indexOf('xxx'));
}