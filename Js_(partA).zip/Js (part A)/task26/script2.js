"use strict";

var result = 0;

for (var key in salaries){
    result += salaries[key];
}