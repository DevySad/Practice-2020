"use strict";

var res = 0;
var name = "";

for (var key in salaries){
    if (res < salaries[key])
        res = salaries[key];
}

alert(name || "нет такого сотрудника!");