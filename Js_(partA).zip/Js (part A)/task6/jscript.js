var ourPlanetName = "Земля";
var userName = "Петя";