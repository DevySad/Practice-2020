var res;

do {
    res = prompt("Enter value > 100: ", 0);
} while (res <= 100 && res != null);