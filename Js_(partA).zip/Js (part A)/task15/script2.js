var i = 0;

while (i < 3){
    alert("номер" + i + "!");  
    i++;
}