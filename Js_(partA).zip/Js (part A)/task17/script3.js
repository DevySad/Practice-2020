function pow(x, n){
    var i = 0;
    var result = 1;
    
    while (i != n){
        result *= x;
        i++;
    }
    
    return result;
}

alert(pow(3, 2));