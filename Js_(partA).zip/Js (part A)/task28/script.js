function addClass(obj, cls){
    var classes = obj.cLassName.split(" ");
    
    if (classes.indexOf(cls) == -1)
        classes.push(cls);
    else
        return;
    
    obj.cLassName = classes.join(' ');
}