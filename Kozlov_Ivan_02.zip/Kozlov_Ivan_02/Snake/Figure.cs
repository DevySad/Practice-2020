﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    class Figure
    {
        protected List<Point> points;

        public void Draw()
        {
            foreach (Point point in points)
                point.Draw();
        }

        internal bool IsHit(Figure figure)
        {
            foreach (var point in points)
            {
                if (figure.IsHit(point))
                    return true;
            }

            return false;
        }

        private bool IsHit(Point _point)
        {
            foreach (var point in points)
            {
                if (point.IsHit(_point))
                    return true;
            }

            return false;
        }
    }
}
