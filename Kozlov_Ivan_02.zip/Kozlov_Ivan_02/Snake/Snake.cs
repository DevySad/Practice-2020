﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    class Snake : Figure
    {
        Direction direction;

        public Snake(Point tail, int length, Direction _direction)
        {
            points = new List<Point>();

            direction = _direction;

            for (int i = 0; i <= length; i++)
            {
                Point point = new Point(tail);
                point.Move(i, direction);
                points.Add(point);
            }
        }

        public void Move()
        {
            Point tail = points.First();
            points.Remove(tail);
            Point head = GetNextPoint();
            points.Add(head);

            tail.Clear();
            head.Draw();
        }

        Point GetNextPoint()
        {
            Point head = points.Last();
            Point nextPoint = new Point(head);
            nextPoint.Move(1, direction);

            return nextPoint;
        }

        public void HandleKey(ConsoleKey key)
        {
            switch (key)
            {
                case ConsoleKey.LeftArrow: direction = Direction.LEFT;
                    break;
                case ConsoleKey.RightArrow: direction = Direction.RIGHT;
                    break;
                case ConsoleKey.UpArrow: direction = Direction.UP;
                    break;
                case ConsoleKey.DownArrow: direction = Direction.DOWN;
                    break;
            }
        }

        public bool Eat(Point food)
        {
            Point head = GetNextPoint();

            if (head.IsHit(food))
            {
                food.sym = head.sym;
                points.Add(food);

                return true;
            }

            return false;
        }

        internal bool IsHitTail()
        {
            var head = points.Last();

            for (int i = 0; i <= points.Count - 2; i++)
            {
                if (head.IsHit(points[i]))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
