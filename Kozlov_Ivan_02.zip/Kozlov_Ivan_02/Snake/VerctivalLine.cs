﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    class VerctivalLine : Figure
    {
        public VerctivalLine(int yUp, int yDown, int x, char sym)
        {
            points = new List<Point>();

            for (int y = yUp; y <= yDown; y++)
                points.Add(new Point(x, y, sym));
        }

    }
}
