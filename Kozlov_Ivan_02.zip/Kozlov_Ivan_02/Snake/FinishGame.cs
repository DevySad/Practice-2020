﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    static class FinishGame
    {
        public static void GameOver()
        {
            Console.ForegroundColor = ConsoleColor.Green;

            for (int i = 25; i <= 55; i++)
            {
                Console.SetCursorPosition(i, 8);
                Console.Write('=');

                Console.SetCursorPosition(i, 12);
                Console.Write('=');
            }

            Console.SetCursorPosition(35, 10);
            Console.Write("Game Over!");
        }
    }
}
