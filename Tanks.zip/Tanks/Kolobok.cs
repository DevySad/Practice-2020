﻿using System;

public class Kolobok
{
    public int X
    {
        get; set;
    }

    public int Y
    {
        get; set;
    }

	public Kolobok()
	{
	}
}
