﻿using System;

public class KolobokView
{
	public KolobokView()
	{
	}
}
