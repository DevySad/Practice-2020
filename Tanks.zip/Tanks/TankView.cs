﻿using System;
using System.Drawing;

public class TankView
{
    Bitmap

    public TankView()
	{

	}
}
