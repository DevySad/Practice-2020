﻿using ClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainView
{
    public partial class FormMain : Form
    {
        Bitmap bitmapMain;
        List<Tank> tankList = new List<Tank>();
        List<Stone> stoneList;

        Tank tank = new Tank(10, 10, new Size(50, 50));

        TankView tankView;
        Graphics graphics;

        private Size sizeGround = new Size(674, 472);
        private int countTanks = 5;
        private int countApples = 5;
        private int entitiesSpeed = 100; 

        public FormMain()
        {
            InitializeComponent();

            CreateBitMapToPicture();
        }

        public void CreateBitMapToPicture()
        {
            bitmapMain = new Bitmap(picture.Width, picture.Height);
            Graphics graphicsMain = Graphics.FromImage(bitmapMain);

            graphicsMain.FillRectangle(Brushes.Black, 0, 0, picture.Width, picture.Height);

            stoneList = StonesCreate.CreateStone();

            StoneView stoneView;

            for (int i = 0; i < stoneList.Count; i++)
            {
                stoneView = new StoneView(stoneList[i], bitmapMain);

                graphics = Graphics.FromImage(bitmapMain);
            }

            for (var i = 0; i < countTanks; i++)
            {
                tankList.Add(new Tank(10 * 10 * i, 0, new Size(30, 33)));

                TankView tankView = new TankView(tankList.Last(), bitmapMain);

                graphics = tankView.graphicsTank;  
            }

            picture.Image = bitmapMain;
        }

        void Upd()
        {
            graphics.Clear(Color.Black);

            tank.X += 1;

            tankView = new TankView(tank, bitmapMain);

            graphics = tankView.graphicsTank;

            picture.Image = bitmapMain;
        }

        private void FormMain_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 113)
            {
                Upd();
            }
        }
    }
}
