﻿using ClassLibrary;
using ClassLibrary.Conrollers;
using ClassLibrary.Models;
using ClassLibrary.Views;
using ClassLibrary.Statics;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ClassLibrary.Controllers;
using System.IO;

namespace MainView
{
    public partial class FormMain : Form
    {
        List<Tank> tankList;
        List<Stone> stoneList;
        List<Bullet> bulletList;
        List<Apple> appleList;
        List<PackmanBullet> packmanBulletList;
        List<River> riverList;
        List<IronWall> ironWallList;
        List<Explosion> explosionList;

        Packman packman;

        TankController tankConroller;
        BulletController bulletController;
        PackmanController packmanController;
        PackmanBulletController packmanBulletController;
        ExplosionController explosionController;

        BitmapToPicture bitmapToPicture;

        public static event EventHandler Changed;

        FormState formState;

        private Size sizeGround;
        private int countTanks;
        private int countApples;
        private int entitiesSpeed;

        private int shotingCycle = 2000;
        private int timeBeforeShot = 0;

        private int points = 0;

        public FormMain()
        {
            InitializeComponent();

            sizeGround = new Size(704, 462);
            countTanks = 5;
            countApples = 5;
            entitiesSpeed = 100;

            lblPoints.Parent = picture;
            lblPoints.BackColor = Color.Transparent;

            picture.Width = sizeGround.Width;
            picture.Height = sizeGround.Height;
    }

        public void StartGame()
        {
            //Create Packman
            packman = new Packman(picture.Width / 2 - 30, picture.Height - 35, new Size(30, 30), EnumWay.UP);


            //Create Walls, Bullets, Packman bullets, Tanks
            stoneList = StonesCreate.CreateStone();
            ironWallList = IronWallCreate.CreateIronWall();
            bulletList = new List<Bullet>();
            explosionList = new List<Explosion>();
            packmanBulletList = new List<PackmanBullet>();
            riverList = CreateRiver.RiverCreate();
            tankList = CreateTanks.TanksCreate(countTanks, picture, stoneList, riverList, ironWallList);
            appleList = ApplesCreate.CreateApples(tankList, stoneList, packman, picture, countApples, riverList, ironWallList);

            //Create Controllers
            tankConroller = new TankController();
            explosionController = new ExplosionController(explosionList);
            bulletController = new BulletController(explosionList);
            packmanBulletController = new PackmanBulletController(packman, packmanBulletList, explosionList);
            packmanController = new PackmanController(packman, entitiesSpeed, stoneList, picture, bulletList, tankList, riverList, ironWallList);

            //Sign on Events
            KeyDown += packmanController.PackmanKeyPress;
            packmanController.Shot += packmanBulletController.HandleShot;

            //Draw
            bitmapToPicture = new BitmapToPicture(new Bitmap(704, 462), stoneList, tankList, picture, packman, appleList, riverList, ironWallList);
            bitmapToPicture.CreateBitmapToPicture();

            //Tick
            timerFirstTank.Enabled = true;
        }

        public void GameOver()
        {
            //Null Controllers
            packmanBulletController = null;
            tankConroller = null;
            bulletController = null;
            packmanController = null;

            //Clear Lists
            tankList.Clear();
            stoneList.Clear();
            bulletList.Clear();
            appleList.Clear();
            packmanBulletList.Clear();

            //Visible and Enabled
            timerFirstTank.Enabled = false;
            picture.Visible = false;
            lblGameOver.Visible = true;
            butGame.Visible = true;
            lblPoints.Visible = false;
            State.Visible = false;

            points = 0;
            packman = null;
            bitmapToPicture = null;

            if (formState != null)
                formState.Close();
        }

        private void TimerFirstTank_Tick(object sender, EventArgs e)
        {
            //Check the end of the game
            if (packmanController.CheckPackmanHealth())
            {
                GameOver();
                return;
            }

            //Update points
            lblPoints.Text = points.ToString();

            //Update Ticks
            timeBeforeShot += timerFirstTank.Interval;

            //The Following Step
            for (int i = 0; i < tankList.Count; i++)
            {
                tankConroller.RandomWay(tankList[i], entitiesSpeed, stoneList, picture, tankList, riverList, ironWallList);

                //Shot
                if (timeBeforeShot == shotingCycle)
                {
                    bulletList.Add(new Bullet(tankList[i], new Size(7, 6)));
                }
            }

            for (int i = 0; i < appleList.Count; i++)
            {
                if (Collides.PackmanApple(appleList[i], packman))
                {
                    appleList.Remove(appleList[i]);

                    appleList = ApplesCreate.CreateApples(tankList, stoneList, packman, picture, countApples, riverList, ironWallList);

                    points++;
                }
            }

            for (int i = 0; i < bulletList.Count; i++)
            {
                bulletController.AlgorithBulletWay(bulletList[i], picture, entitiesSpeed, stoneList, bulletList, tankList, ironWallList);
            }

            if (timeBeforeShot == shotingCycle)
                timeBeforeShot = 0;

            packmanBulletController.AlgorithBulletWay(packmanBulletList, picture, entitiesSpeed, stoneList, tankList, countTanks, riverList, ironWallList);

            //Change X,Y for Form State
            if (Changed != null)
                Changed(this, EventArgs.Empty);

            //Draw Step
            bitmapToPicture.UpdateBitmapToPicture(tankList, bulletList, packman, packmanBulletList, explosionList);

            explosionController.ClearList();
        }

        private void ButGame_MouseClick(object sender, MouseEventArgs e)
        {
            StartGame();

            //Visible and Enables
            butGame.Visible = false;
            picture.Visible = true;
            lblGameOver.Visible = false;
            lblPoints.Visible = true;
            State.Visible = true;

            lblPoints.Text = points.ToString();

            FormTextFile();
        }

        private void State_Click(object sender, EventArgs e)
        {
            formState = new FormState(tankList, appleList, packman);

            Changed += formState.HandleChange;

            formState.Show();
        }

        private void FormTextFile()
        {
            using (StreamWriter fileStream = File.CreateText(@"..\..\..\Report.txt"))
            {
                fileStream.WriteLine("Tanks");
                fileStream.WriteLine("");

                for (int i = 0; i < tankList.Count; i++)
                    fileStream.WriteLine("t" + (i + 1).ToString() + " X: " + tankList[i].X.ToString() + " Y: " + tankList[i].Y.ToString());

                fileStream.WriteLine("");
                fileStream.WriteLine("Walls");
                fileStream.WriteLine("");

                for (int i = 0; i < stoneList.Count; i++)
                    fileStream.WriteLine("w" + (i + 1).ToString() + " X: " + stoneList[i].X.ToString() + " Y: " + stoneList[i].Y.ToString());

                fileStream.WriteLine("");
                fileStream.WriteLine("Iron Walls");
                fileStream.WriteLine("");

                for (int i = 0; i < ironWallList.Count; i++)
                    fileStream.WriteLine("iw" + (i + 1).ToString() + " X: " + ironWallList[i].X.ToString() + " Y: " + ironWallList[i].Y.ToString());

                fileStream.WriteLine("");
                fileStream.WriteLine("River");
                fileStream.WriteLine("");

                for (int i = 0; i < riverList.Count; i++)
                    fileStream.WriteLine("r" + (i + 1).ToString() + " X: " + riverList[i].X.ToString() + " Y: " + riverList[i].Y.ToString());

                fileStream.WriteLine("");
                fileStream.WriteLine("Packman");
                fileStream.WriteLine("");

                fileStream.WriteLine("p" + " X: " + packman.X.ToString() + " Y: " + packman.Y.ToString());

                fileStream.WriteLine("");
                fileStream.WriteLine("Apples");
                fileStream.WriteLine("");

                for (int i = 0; i < appleList.Count; i++)
                    fileStream.WriteLine("a" + (i + 1).ToString() + " X: " + appleList[i].X.ToString() + " Y: " + appleList[i].Y.ToString());
            }
        }
    }
}
