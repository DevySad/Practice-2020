﻿using ClassLibrary;
using ClassLibrary.Conrollers;
using ClassLibrary.Models;
using ClassLibrary.Views;
using ClassLibrary.Statics;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ClassLibrary.Controllers;

namespace MainView
{
    public partial class FormMain : Form
    {
        List<Tank> tankList;
        List<Stone> stoneList;
        List<Bullet> bulletList;
        List<Apple> appleList;
        List<PackmanBullet> packmanBulletList;
        List<River> riverList;

        Packman packman;

        TankController tankConroller;
        BulletController bulletController;
        PackmanController packmanController;
        PackmanBulletController packmanBulletController;

        BitmapToPicture bitmapToPicture;

        public static event EventHandler Changed;

        FormState formState;

        private Size sizeGround;
        private int countTanks;
        private int countApples;
        private int entitiesSpeed;

        private int shotingCycle = 2000;
        private int timeBeforeShot = 0;

        private int points = 0;

        public FormMain()
        {
            InitializeComponent();

            sizeGround = new Size(704, 462);
            countTanks = 5;
            countApples = 5;
            entitiesSpeed = 100;

            lblPoints.Parent = picture;
            lblPoints.BackColor = Color.Transparent;

            picture.Width = sizeGround.Width;
            picture.Height = sizeGround.Height;
    }

        public void StartGame()
        {
            //Create Packman
            packman = new Packman(picture.Width / 2 - 30, picture.Height - 35, new Size(30, 30), EnumWay.UP);


            //Create Walls, Bullets, Packman bullets, Tanks
            stoneList = StonesCreate.CreateStone();
            bulletList = new List<Bullet>();
            packmanBulletList = new List<PackmanBullet>();
            riverList = CreateRiver.RiverCreate();
            tankList = CreateTanks.TanksCreate(countTanks, picture, stoneList, riverList);
            appleList = ApplesCreate.CreateApples(tankList, stoneList, packman, picture, countApples, riverList);

            //Create Controllers
            tankConroller = new TankController();
            bulletController = new BulletController();
            packmanBulletController = new PackmanBulletController(packman, packmanBulletList);
            packmanController = new PackmanController(packman, entitiesSpeed, stoneList, picture, bulletList, tankList, riverList);

            //Sign on Events
            KeyDown += packmanController.PackmanKeyPress;
            packmanController.Shot += packmanBulletController.HandleShot;

            //Draw
            bitmapToPicture = new BitmapToPicture(new Bitmap(704, 472), stoneList, tankList, picture, packman, appleList, riverList);
            bitmapToPicture.CreateBitmapToPicture();

            //Tick
            timerFirstTank.Enabled = true;
        }

        public void GameOver()
        {
            //Null Controllers
            packmanBulletController = null;
            tankConroller = null;
            bulletController = null;
            packmanController = null;

            //Clear Lists
            tankList.Clear();
            stoneList.Clear();
            bulletList.Clear();
            appleList.Clear();
            packmanBulletList.Clear();

            //Visible and Enabled
            timerFirstTank.Enabled = false;
            picture.Visible = false;
            lblGameOver.Visible = true;
            butGame.Visible = true;
            lblPoints.Visible = false;
            State.Visible = false;

            points = 0;
            packman = null;
            bitmapToPicture = null;

            if (formState != null)
                formState.Close();
        }

        private void TimerFirstTank_Tick(object sender, EventArgs e)
        {
            //Check the end of the game
            if (packmanController.CheckPackmanHealth())
            {
                GameOver();
                return;
            }

            //Update points
            lblPoints.Text = points.ToString();

            //Update Ticks
            timeBeforeShot += timerFirstTank.Interval;

            //The Following Step
            for (int i = 0; i < tankList.Count; i++)
            {
                tankConroller.RandomWay(tankList[i], entitiesSpeed, stoneList, picture, tankList, riverList);

                //Shot
                if (timeBeforeShot == shotingCycle)
                {
                    bulletList.Add(new Bullet(tankList[i], new Size(7, 6)));
                }
            }

            for (int i = 0; i < appleList.Count; i++)
            {
                if (Collides.PackmanApple(appleList[i], packman))
                {
                    appleList.Remove(appleList[i]);

                    appleList = ApplesCreate.CreateApples(tankList, stoneList, packman, picture, countApples, riverList);

                    points++;
                }
            }

            for (int i = 0; i < bulletList.Count; i++)
            {
                bulletController.AlgorithBulletWay(bulletList[i], picture, entitiesSpeed, stoneList, bulletList, tankList);
            }

            if (timeBeforeShot == shotingCycle)
                timeBeforeShot = 0;

            packmanBulletController.AlgorithBulletWay(packmanBulletList, picture, entitiesSpeed, stoneList, tankList, countTanks, riverList);

            //Change X,Y for Form State
            if (Changed != null)
                Changed(this, EventArgs.Empty);

            //Draw Step
            bitmapToPicture.UpdateBitmapToPicture(tankList, bulletList, packman, packmanBulletList);
        }

        private void ButGame_MouseClick(object sender, MouseEventArgs e)
        {
            StartGame();

            //Visible and Enables
            butGame.Visible = false;
            picture.Visible = true;
            lblGameOver.Visible = false;
            lblPoints.Visible = true;
            State.Visible = true;

            lblPoints.Text = points.ToString();
        }

        private void State_Click(object sender, EventArgs e)
        {
            formState = new FormState(tankList, appleList, packman);

            Changed += formState.HandleChange;

            formState.Show();
        }
    }
}
