﻿using ClassLibrary;
using ClassLibrary.Conrollers;
using ClassLibrary.Models;
using ClassLibrary.Views;
using ClassLibrary.Statics;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ClassLibrary.Controllers;

namespace MainView
{
    public partial class FormMain : Form
    {
        List<Tank> tankList;
        List<Stone> stoneList;
        List<Bullet> bulletList;
        List<Apple> appleList;

        Packman packman;
        PackmanBullet packmanBullet;

        TankController tankConroller;
        BulletController bulletController;
        PackmanController packmanController;
        PackmanBulletController packmanBulletController;

        BitmapToPicture bitmapToPicture;
      
        private Size sizeGround = new Size(704, 472);
        private int countTanks = 5;
        private int countApples = 5;
        private int entitiesSpeed = 100;

        private int shotingCycle = 2000;
        private int timeBeforeShot = 0;

        private int points = 0;

        public FormMain()
        {
            InitializeComponent();

            lblPoints.Parent = picture;

            lblPoints.BackColor = Color.Transparent;
        }

        public void StartGame()
        {
            packman = new Packman(picture.Width / 2 - 30, picture.Height - 35, new Size(30, 30), EnumWay.UP);

            stoneList = StonesCreate.CreateStone();

            bulletList = new List<Bullet>();

            tankList = CreateTanks.TanksCreate(countTanks, picture, stoneList);

            tankConroller = new TankController();

            bulletController = new BulletController();

            packmanBulletController = new PackmanBulletController(packman);

            packmanController = new PackmanController(packman, entitiesSpeed, stoneList, picture, bulletList, tankList, packmanBullet);

            appleList = ApplesCreate.CreateApples(tankList, stoneList, packman, picture, countApples);

            KeyDown += packmanController.PackmanKeyPress;

            packmanController.Shot += packmanBulletController.HandeleShot;

            bitmapToPicture = new BitmapToPicture(new Bitmap(704, 472), stoneList, tankList, picture, packman, appleList);

            bitmapToPicture.CreateBitmapToPicture();

            timerFirstTank.Enabled = true;
        }

        public void GameOver()
        {
            timerFirstTank.Enabled = false;

            picture.Visible = false;

            lblGameOver.Visible = true;

            butGame.Visible = true;

            points = 0;

            lblPoints.Visible = false;

            tankList.Clear();

            stoneList.Clear();

            bulletList.Clear();

            packman = null;

            tankConroller = null;

            bulletController = null;

            packmanController = null;

            bitmapToPicture = null;
        }

        private void TimerFirstTank_Tick(object sender, System.EventArgs e)
        {
            if (packmanController.CheckPackmanHealth())
            {
                GameOver();

                return;
            }

            lblPoints.Text = points.ToString();

            timeBeforeShot += timerFirstTank.Interval;

            for (int i = 0; i < tankList.Count; i++)
            {
                tankConroller.RandomWay(tankList[i], entitiesSpeed, stoneList, picture, tankList);

                if (timeBeforeShot == shotingCycle)
                {
                    bulletList.Add(new Bullet(tankList[i], new Size(7, 6)));
                }
            }

            for (int i = 0; i < appleList.Count; i++)
            {
                if (Collides.PackmanApple(appleList[i], packman))
                {
                    appleList.Remove(appleList[i]);

                    appleList = ApplesCreate.CreateApples(tankList, stoneList, packman, picture, countApples);

                    points++;
                }
            }

            for (int i = 0; i < bulletList.Count; i++)
            {
                bulletController.AlgorithBulletWay(bulletList[i], picture, entitiesSpeed, stoneList, bulletList, tankList);
            }

            if (timeBeforeShot == shotingCycle)
                timeBeforeShot = 0;

           /* if (packmanBullet != null)
                MessageBox.Show("y");*/
              //  packmanBulletController.AlgorithBulletWay(packmanBullet, picture, entitiesSpeed, stoneList, tankList, countTanks);

            bitmapToPicture.UpdateBitmapToPicture(tankList, bulletList, packman, packmanBullet);
        }

        private void ButGame_Click(object sender, EventArgs e)
        {
            StartGame();

            butGame.Visible = false;

            picture.Visible = true;

            lblGameOver.Visible = false;

            lblPoints.Visible = true;

            lblPoints.Text = points.ToString();
        }
    }
}
