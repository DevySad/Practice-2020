﻿namespace MainView
{
    partial class FormState
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dGVState = new System.Windows.Forms.DataGridView();
            this.Col_1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dGVState)).BeginInit();
            this.SuspendLayout();
            // 
            // dGVState
            // 
            this.dGVState.BackgroundColor = System.Drawing.Color.Black;
            this.dGVState.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVState.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Col_1,
            this.Col_2,
            this.Col_3});
            this.dGVState.Location = new System.Drawing.Point(12, 12);
            this.dGVState.Name = "dGVState";
            this.dGVState.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dGVState.Size = new System.Drawing.Size(411, 203);
            this.dGVState.TabIndex = 0;
            // 
            // Col_1
            // 
            this.Col_1.HeaderText = "Название объекта";
            this.Col_1.Name = "Col_1";
            this.Col_1.Width = 150;
            // 
            // Col_2
            // 
            this.Col_2.HeaderText = "Координата: X";
            this.Col_2.Name = "Col_2";
            this.Col_2.Width = 110;
            // 
            // Col_3
            // 
            this.Col_3.HeaderText = "Координата: Y";
            this.Col_3.Name = "Col_3";
            this.Col_3.Width = 110;
            // 
            // FormState
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(435, 229);
            this.Controls.Add(this.dGVState);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormState";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormState_FormClosed);
            this.Load += new System.EventHandler(this.FormState_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dGVState)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dGVState;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_3;
    }
}