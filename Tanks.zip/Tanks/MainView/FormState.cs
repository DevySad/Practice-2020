﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ClassLibrary.Models;

namespace MainView
{
    public partial class FormState : Form
    {
        private List<Tank> tankList;
        private List<Apple> appleList;
        private Packman packman;

        public FormState(List<Tank> tankList, List<Apple> appleList, Packman packman)
        {
            InitializeComponent();

            this.tankList = tankList;
            this.appleList = appleList;
            this.packman = packman;
        }

        public void HandleChange(object sender, EventArgs e)
        {
            FillGrid();
        }

        private void FillGrid()
        {
           dGVState.Rows[0].Cells[0].Value = "Колобок";
           dGVState.Rows[0].Cells[1].Value = packman.X.ToString();
           dGVState.Rows[0].Cells[2].Value = packman.Y.ToString();
            
            for (int i = 0; i < tankList.Count; i++)
            {
                dGVState.Rows[i + 1].Cells[0].Value = "Танк_" + (i + 1).ToString();
                dGVState.Rows[i + 1].Cells[1].Value = tankList[i].X.ToString();
                dGVState.Rows[i + 1].Cells[2].Value = tankList[i].Y.ToString();
            }

            for (int i = 0; i < appleList.Count; i++)
            {
                dGVState.Rows[tankList.Count + i + 1].Cells[0].Value = "Яблоко_" + (i + 1).ToString();
                dGVState.Rows[tankList.Count + i + 1].Cells[1].Value = appleList[i].X.ToString();
                dGVState.Rows[tankList.Count + i + 1].Cells[2].Value = appleList[i].Y.ToString();
            }
        }

        private void FormState_FormClosed(object sender, FormClosedEventArgs e)
        {
            FormMain.Changed -= HandleChange;
        }

        private void FormState_Load(object sender, EventArgs e)
        {
            dGVState.RowCount = tankList.Count + appleList.Count + 1;

            FillGrid();
        }
    }
}
