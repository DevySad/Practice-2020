﻿using System.Drawing;
using System.Windows.Forms;
using ClassLibrary.Models;
using System.Collections.Generic;

namespace ClassLibrary.Conrollers
{
    public class BulletController
    {
        private List<Explosion> explosionList;

        public BulletController(List<Explosion> explosionList)
        {
            this.explosionList = explosionList;
        }

        public void MoveBullet(Bullet bullet, int entitieSpeed)
        {
            switch (bullet.Way)
            {
                case EnumWay.UP:
                    bullet.Y -= (int)(entitieSpeed * 0.2);
                    break;
                case EnumWay.DOWN:
                    bullet.Y += (int)(entitieSpeed * 0.2);
                    break;
                case EnumWay.RIGHT:
                    bullet.X += (int)(entitieSpeed * 0.2);
                    break;
                case EnumWay.LEFT:
                    bullet.X -= (int)(entitieSpeed * 0.2);
                    break;
            }
        }

        public void AlgorithBulletWay(Bullet bullet, PictureBox picture, int entitiesSpeed, List<Stone> stoneList, 
            List<Bullet> bulletList, List<Tank> tankList, List<IronWall> ironWallList)
        {
            MoveBullet(bullet, entitiesSpeed);

            for (int i = 0; i < stoneList.Count; i++)
            {
                if (Collides.BulletDestroyStone(bullet, stoneList[i]))
                {
                    explosionList.Add(new Explosion(bullet, new Size(30, 30)));

                    bulletList.Remove(bullet);

                    stoneList.Remove(stoneList[i]);
                }
            }

            if (Collides.BulletGround(bullet, picture, ironWallList) 
                || Collides.BulletToTankAndBullet(bullet, tankList, bulletList))
            {
                explosionList.Add(new Explosion(bullet, new Size(30, 30)));

                bulletList.Remove(bullet);
            }
        }
    } 
}
