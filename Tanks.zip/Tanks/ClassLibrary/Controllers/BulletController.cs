﻿using System;
using System.Windows.Forms;
using ClassLibrary.Models;
using System.Collections.Generic;

namespace ClassLibrary.Conrollers
{
    public class BulletController
    {
        public void MoveBullet(Bullet bullet, int entitieSpeed)
        {
            switch (bullet.Way)
            {
                case EnumWay.UP:
                    bullet.Y -= (int)(entitieSpeed * 0.2);
                    break;
                case EnumWay.DOWN:
                    bullet.Y += (int)(entitieSpeed * 0.2);
                    break;
                case EnumWay.RIGHT:
                    bullet.X += (int)(entitieSpeed * 0.2);
                    break;
                case EnumWay.LEFT:
                    bullet.X -= (int)(entitieSpeed * 0.2);
                    break;
            }
        }

        public void AlgorithBulletWay(Bullet bullet, PictureBox picture, int entitiesSpeed, List<Stone> stoneList, 
            List<Bullet> bulletList, List<Tank> tankList)
        {
            MoveBullet(bullet, entitiesSpeed);

            if (Collides.BulletStoneGround(bullet, stoneList, picture) 
                || Collides.BulletToTankAndBullet(bullet, tankList, bulletList))
            {
                bulletList.Remove(bullet);
            }
        }
    } 
}
