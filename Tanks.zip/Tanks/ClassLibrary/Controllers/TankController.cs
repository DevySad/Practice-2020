﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ClassLibrary.Models;

namespace ClassLibrary.Conrollers
{
    public class TankController
    {
        public void MoveTank(Tank tank, int entitieSpeed)
        {
            switch (tank.Way)
            {
                case EnumWay.UP:
                    tank.Y -= (int)(entitieSpeed * 0.06);
                    break;
                case EnumWay.DOWN:
                    tank.Y += (int)(entitieSpeed * 0.06);
                    break;
                case EnumWay.RIGHT:
                    tank.X += (int)(entitieSpeed * 0.06);
                    break;
                case EnumWay.LEFT:
                    tank.X -= (int)(entitieSpeed * 0.06);
                    break;
            }
        }

        public void ResetTank(Tank tank, int entitieSpeed)
        {
            switch (tank.Way)
            {
                case EnumWay.UP:
                    tank.Y += (int)(entitieSpeed * 0.06) + 1;
                    break;
                case EnumWay.DOWN:
                    tank.Y -= (int)(entitieSpeed * 0.06) + 1;
                    break;
                case EnumWay.RIGHT:
                    tank.X -= (int)(entitieSpeed * 0.06) + 1;
                    break;
                case EnumWay.LEFT:
                    tank.X += (int)(entitieSpeed * 0.06) + 1;
                    break;
            }
        }

        public void RandomWay(Tank tank, int entitiesSpeed, List<Stone> stoneList, 
            PictureBox picture, List<Tank> tankList, List<River> riverList, List<IronWall> ironWallList)
        {
            MoveTank(tank, entitiesSpeed);

            if (Collides.TankToStone(tank, stoneList, riverList, picture, ironWallList))
            {
                ResetTank(tank, entitiesSpeed);

                switch (tank.Way)
                {
                    case EnumWay.UP:
                        tank.Way = EnumWay.RIGHT;
                        break;
                    case EnumWay.DOWN:
                        tank.Way = EnumWay.LEFT;
                        break;
                    case EnumWay.RIGHT:
                        tank.Way = EnumWay.DOWN;
                        break;
                    case EnumWay.LEFT:
                        tank.Way = EnumWay.UP;
                        break;
                }

                MoveTank(tank, entitiesSpeed);

                if (Collides.TankToStone(tank, stoneList, riverList, picture, ironWallList))
                {
                    ResetTank(tank, entitiesSpeed);

                    switch (tank.Way)
                    {
                        case EnumWay.UP:
                            tank.Way = EnumWay.DOWN;
                            break;
                        case EnumWay.DOWN:
                            tank.Way = EnumWay.UP;
                            break;
                        case EnumWay.RIGHT:
                            tank.Way = EnumWay.LEFT;
                            break;
                        case EnumWay.LEFT:
                            tank.Way = EnumWay.RIGHT;
                            break;
                    }
                }
            }

            if (Collides.TanksCollide(tank, tankList))
            {
                switch (tank.Way)
                {
                    case EnumWay.UP:
                        tank.Way = EnumWay.DOWN;
                        break;
                    case EnumWay.DOWN:
                        tank.Way = EnumWay.UP;
                        break;
                    case EnumWay.RIGHT:
                        tank.Way = EnumWay.LEFT;
                        break;
                    case EnumWay.LEFT:
                        tank.Way = EnumWay.RIGHT;
                        break;
                }
            }
        }
    }
}
