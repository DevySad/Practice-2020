﻿using ClassLibrary.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;

namespace ClassLibrary.Controllers
{
    public class PackmanBulletController
    {
        private Packman packman;
        private List<PackmanBullet> packmanBulletList;
        private List<Explosion> explosionList;

        public void HandleShot(object sender, EventArgs e)
        {
            packmanBulletList.Add(new PackmanBullet(packman, new Size(7, 6)));
        }

        public PackmanBulletController(Packman packman, List<PackmanBullet> packmanBulletList, List<Explosion> explosionList)
        {
            this.packman = packman;
            this.packmanBulletList = packmanBulletList;
            this.explosionList = explosionList;
        }

        public void MoveBullet(PackmanBullet bullet, int entitiesSpeed)
        {
            switch (bullet.Way)
            {
                case EnumWay.UP:
                    bullet.Y -= (int)(entitiesSpeed * 0.2);
                    break;
                case EnumWay.DOWN:
                    bullet.Y += (int)(entitiesSpeed * 0.2);
                    break;
                case EnumWay.RIGHT:
                    bullet.X += (int)(entitiesSpeed * 0.2);
                    break;
                case EnumWay.LEFT:
                    bullet.X -= (int)(entitiesSpeed * 0.2);
                    break;
            }
        }

        public void AlgorithBulletWay(List<PackmanBullet> packmanBulletList, PictureBox picture, int entitiesSpeed, List<Stone> stoneList,
            List<Tank> tankList, int countTanks, List<River> riverList, List<IronWall> ironWallList)
        {
            for (int i = 0; i < packmanBulletList.Count; i++)
            {
                MoveBullet(packmanBulletList[i], entitiesSpeed);

                if (Collides.PackmanBulletToGroundIronWall(packmanBulletList[i], picture, ironWallList))
                {
                    explosionList.Add(new Explosion(packmanBulletList[i], new Size(20, 20)));

                    packmanBulletList.Remove(packmanBulletList[i]);

                    continue;
                }

                for (int j = 0; j < stoneList.Count; j++)
                {
                    if (Collides.PackmanBulletDestroyStone(packmanBulletList[i], stoneList[j]))
                    {
                        explosionList.Add(new Explosion(packmanBulletList[i], new Size(20, 20)));

                        packmanBulletList.Remove(packmanBulletList[i]);

                        stoneList.Remove(stoneList[j]);

                        return;
                    }
                }

                for (int j = 0; j < tankList.Count; j++)
                {
                    if (Collides.PackmanBulletToTank(tankList[j], packmanBulletList[i]))
                    {
                        explosionList.Add(new Explosion(packmanBulletList[i], new Size(20, 20)));

                        tankList.Remove(tankList[j]);

                        tankList = CreateTanks.TanksCreate(countTanks, picture, stoneList, riverList, ironWallList);

                        packmanBulletList.Remove(packmanBulletList[i]);

                        return;
                    }
                }
            }

        
        }
    }
}

  