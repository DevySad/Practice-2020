﻿using ClassLibrary.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;

namespace ClassLibrary.Controllers
{
    public class PackmanBulletController
    {
        private Packman packman;
        private List<PackmanBullet> packmanBulletList;

        public void HandleShot(object sender, EventArgs e)
        {
            packmanBulletList.Add(new PackmanBullet(packman, new Size(7, 6)));
        }

        public PackmanBulletController(Packman packman, List<PackmanBullet> packmanBulletList)
        {
            this.packman = packman;
            this.packmanBulletList = packmanBulletList;
        }

        public void MoveBullet(PackmanBullet bullet, int entitiesSpeed)
        {
            switch (bullet.Way)
            {
                case EnumWay.UP:
                    bullet.Y -= (int)(entitiesSpeed * 0.2);
                    break;
                case EnumWay.DOWN:
                    bullet.Y += (int)(entitiesSpeed * 0.2);
                    break;
                case EnumWay.RIGHT:
                    bullet.X += (int)(entitiesSpeed * 0.2);
                    break;
                case EnumWay.LEFT:
                    bullet.X -= (int)(entitiesSpeed * 0.2);
                    break;
            }
        }

        public void AlgorithBulletWay(List<PackmanBullet> packmanBulletList, PictureBox picture, int entitiesSpeed, List<Stone> stoneList,
            List<Tank> tankList, int countTanks, List<River> riverList)
        {
            for (int i = 0; i < packmanBulletList.Count; i++)
            {
                MoveBullet(packmanBulletList[i], entitiesSpeed);

                if (Collides.PackmanBulletToStoneGround(packmanBulletList[i], stoneList, picture) )
                {
                    packmanBulletList.Remove(packmanBulletList[i]);

                    continue;
                }

                for (int j = 0; j < tankList.Count; j++)
                {

                    if (Collides.PackmanBulletToTank(tankList[j], packmanBulletList[i]))
                    {
                        tankList.Remove(tankList[j]);

                        tankList = CreateTanks.TanksCreate(countTanks, picture, stoneList, riverList);

                        packmanBulletList.Remove(packmanBulletList[i]);

                        break;
                    }


                }
            }

        
        }
    }
}

  