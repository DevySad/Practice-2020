﻿using ClassLibrary.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;

namespace ClassLibrary.Controllers
{
    public class PackmanBulletController
    {
        public PackmanBullet packmanBullet;
        private Packman packman;

        public void HandeleShot(object sender, EventArgs e)
        {
            packmanBullet = new PackmanBullet(packman, new Size(7, 6));
        }

        public PackmanBulletController(Packman packman)
        {
            this.packman = packman;
        }

        public void MoveBullet(PackmanBullet bullet, int entitiesSpeed)
        {
            switch (bullet.Way)
            {
                case EnumWay.UP:
                    bullet.Y -= (int)(entitiesSpeed * 0.2);
                    break;
                case EnumWay.DOWN:
                    bullet.Y += (int)(entitiesSpeed * 0.2);
                    break;
                case EnumWay.RIGHT:
                    bullet.X += (int)(entitiesSpeed * 0.2);
                    break;
                case EnumWay.LEFT:
                    bullet.X -= (int)(entitiesSpeed * 0.2);
                    break;
            }
        }

        public void AlgorithBulletWay(PackmanBullet bullet, PictureBox picture, int entitiesSpeed, List<Stone> stoneList,
            List<Tank> tankList, int countTanks)
        {
            MoveBullet(bullet, entitiesSpeed);

            for (int i = 0; i < tankList.Count; i++)
            {
                if (Collides.PackmanBulletToStoneGround(bullet, stoneList, picture))
                {
                    if (Collides.PackmanBulletToTank(tankList[i], bullet))
                    {
                        tankList.Remove(tankList[i]);

                        tankList = CreateTanks.TanksCreate(countTanks, picture, stoneList);
                    }

                    bullet = null;
                }
            }
        }
    }
}
