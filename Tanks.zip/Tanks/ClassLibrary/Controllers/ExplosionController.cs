﻿using System.Drawing;
using System.Collections.Generic;
using ClassLibrary.Models;

namespace ClassLibrary.Controllers
{
    public class ExplosionController
    {
        private List<Explosion> explosionList;

        public ExplosionController(List<Explosion> explosionList)
        {
            this.explosionList = explosionList;
        }

        public void ClearList()
        {
            explosionList.Clear();
        }
    }
}
