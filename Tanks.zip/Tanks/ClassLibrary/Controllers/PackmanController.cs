﻿using System;
using System.Windows.Forms;
using ClassLibrary.Models;
using System.Collections.Generic;
using System.Drawing;

namespace ClassLibrary.Views
{
    public class PackmanController
    {
        private Packman packman;
        private int entitieSpeed;
        private List<Stone> stoneList;
        private PictureBox picture;
        private List<Bullet> bulletList;
        private List<Tank> tankList;
        private List<River> riverList;

        public event EventHandler Shot;

        public PackmanController(Packman packman, int entitieSpeed, List<Stone> stoneList,
            PictureBox picture, List<Bullet> bulletList, List<Tank> tankList, List<River> riverList)
        {
            this.packman = packman;
            this.entitieSpeed = entitieSpeed;
            this.stoneList = stoneList;
            this.picture = picture;
            this.bulletList = bulletList;
            this.tankList = tankList;
            this.riverList = riverList;
        }

        public void StepPackman()
        {
            switch (packman.Way)
            {
                case EnumWay.UP:
                    packman.Y -= (int)(entitieSpeed * 0.03);
                    break;
                case EnumWay.DOWN:
                    packman.Y += (int)(entitieSpeed * 0.03);
                    break;
                case EnumWay.RIGHT:
                    packman.X += (int)(entitieSpeed * 0.03);
                    break;
                case EnumWay.LEFT:
                    packman.X -= (int)(entitieSpeed * 0.03);
                    break;
            }
        }

        public void ResetStepPackman()
        {
            switch (packman.Way)
            {
                case EnumWay.UP:
                    packman.Y += (int)(entitieSpeed * 0.03);
                    break;
                case EnumWay.DOWN:
                    packman.Y -= (int)(entitieSpeed * 0.03);
                    break;
                case EnumWay.RIGHT:
                    packman.X -= (int)(entitieSpeed * 0.03);
                    break;
                case EnumWay.LEFT:
                    packman.X += (int)(entitieSpeed * 0.03);
                    break;
            }
        }

        public bool CheckPackmanHealth()
        {
            return Collides.PackmanBulletTank(packman, bulletList, tankList);
        }

        public void MovePackman()
        {
            StepPackman();

            if (Collides.PackmanToStoneGround(packman, stoneList, picture, riverList))
            {
                ResetStepPackman();
            }
        }

        public void PackmanKeyPress(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    {
                        packman.Way = EnumWay.UP;
                        MovePackman();

                        break;
                    }
                case Keys.Down:
                    {
                        packman.Way = EnumWay.DOWN;
                        MovePackman();

                        break;
                    }

                case Keys.Right:
                    {
                        packman.Way = EnumWay.RIGHT;
                        MovePackman();

                        break;
                    }

                case Keys.Left:
                    {
                        packman.Way = EnumWay.LEFT;
                        MovePackman();

                        break;
                    }
                case Keys.Space:
                    {
                        Shot(this, EventArgs.Empty);

                        break;
                    }
            }   
        }
    }

    
}
