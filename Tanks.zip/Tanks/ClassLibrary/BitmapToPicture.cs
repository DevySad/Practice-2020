﻿using System.Collections.Generic;
using System.Drawing;
using ClassLibrary.Views;
using System.Windows.Forms;
using ClassLibrary.Models;

namespace ClassLibrary
{
    public class BitmapToPicture
    {
        private Bitmap bitmap;
        private Graphics graphics;
        private List<Stone> stoneList;
        private List<Tank> tankList;
        private PictureBox picture;
        private StoneView stoneView;
        private TankView tankView;
        private BulletView bulletView;
        private Packman packman;
        private PackmanView packmanView;
        private List<Apple> appleList;
        private AppleView appleView;
        private PackmanBulletView packmanBulletView;

        public BitmapToPicture(Bitmap bitmap, List<Stone> stoneList, List<Tank> tankList, PictureBox picture,
            Packman packman, List<Apple> appleList)
        {
            this.bitmap = bitmap;
            this.stoneList = stoneList;
            this.tankList = tankList;
            this.picture = picture;
            this.packman = packman;
            this.appleList = appleList;
        }

        public void CreateBitmapToPicture()
        {
            graphics = Graphics.FromImage(bitmap);

            graphics.FillRectangle(Brushes.Black, 0, 0, picture.Width, picture.Height);

            ResetBitmapToPicture();

            for (var i = 0; i < tankList.Count; i++)
            {
                tankView = new TankView(tankList[i], bitmap);

                graphics = tankView.graphicsTank;
            }

            for (var i = 0; i < appleList.Count; i++)
            {
                appleView = new AppleView(appleList[i], bitmap);

                graphics = appleView.graphicsApple;
            }

            packmanView = new PackmanView(packman, bitmap);

            graphics = packmanView.graphicsPackman;

            picture.Image = bitmap;

        }

        public void ResetBitmapToPicture()
        {
            for (int i = 0; i < stoneList.Count; i++)
            {
                stoneView = new StoneView(stoneList[i], bitmap);

                graphics = Graphics.FromImage(bitmap);
            }
        }

        public void UpdateBitmapToPicture(List<Tank> tankList, List<Bullet> bulletList,
            Packman packman, PackmanBullet packmanBullet)
        {
            graphics.Clear(Color.Black);

            ResetBitmapToPicture();

            for (int i = 0; i < tankList.Count; i++)
            {
                tankView = new TankView(tankList[i], bitmap);

                graphics = tankView.graphicsTank;
            }

            for (int i = 0; i < bulletList.Count; i++)
            {
                bulletView = new BulletView(bulletList[i], bitmap);

                graphics = bulletView.graphicsBullet;
            }

            for (var i = 0; i < appleList.Count; i++)
            {
                appleView = new AppleView(appleList[i], bitmap);

                graphics = appleView.graphicsApple;
            }

            packmanView = new PackmanView(packman, bitmap);

            graphics = packmanView.graphicsPackman;

            /*if (packmanBullet != null)
            {
                packmanBulletView = new PackmanBulletView(packmanBullet, bitmap);

                graphics = packmanBulletView.graphicsPackmanBullet;
            }*/

            picture.Image = bitmap;
            
        }
    }
}
