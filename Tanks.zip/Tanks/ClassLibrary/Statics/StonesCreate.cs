﻿using System.Drawing;
using System.Collections.Generic;


namespace ClassLibrary
{
    public static class StonesCreate
    {
        private static List<Stone> stoneList = new List<Stone>();

        public static List<Stone> CreateStone()
        {
            VerticalStonesUp();

            VerticalStonesDown();

            VerticalStonesMiddle();

            HorizontalStone();

            return stoneList;
        }

        private static void HorizontalStone()
        {
            for (int i = 0; i < 2; i++)
            {
                stoneList.Add(new Stone(292 + 36 * i, 172, new Size(37, 33)));
            }

            for (int i = 0; i < 2; i++)
            {
                stoneList.Add(new Stone(339 + 33 * i, 250, new Size(33, 33)));
            }

            stoneList.Add(new Stone(146, 315, new Size(40, 33)));

            stoneList.Add(new Stone(146, 106, new Size(40, 33)));

            stoneList.Add(new Stone(332, 139, new Size(33, 33)));
        }

        private static void VerticalStonesMiddle()
        {
            for (int i = 0; i < 2; i++)
            {
                stoneList.Add(new Stone(186, 195 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 2; i++)
            {
                stoneList.Add(new Stone(478, 195 + 33 * i, new Size(33, 33)));
            }
        }

        private static void VerticalStonesDown()
        {
            for (int i = 0; i < 5; i++)
            {
                stoneList.Add(new Stone(40, 250 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 5; i++)
            {
                stoneList.Add(new Stone(113, 250 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 3; i++)
            {
                stoneList.Add(new Stone(186, 315 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 5; i++)
            {
                stoneList.Add(new Stone(259, 250 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 2; i++)
            {
                stoneList.Add(new Stone(332, 350 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 5; i++)
            {
                stoneList.Add(new Stone(405, 250 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 3; i++)
            {
                stoneList.Add(new Stone(478, 315 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 5; i++)
            {
                stoneList.Add(new Stone(551, 250 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 5; i++)
            {
                stoneList.Add(new Stone(624, 250 + 33 * i, new Size(33, 33)));
            }
        }

        private static void VerticalStonesUp()
        {
            for (int i = 0; i < 5; i++)
            {
                stoneList.Add(new Stone(40, 40 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 5; i++)
            {
                stoneList.Add(new Stone(113, 40 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 3; i++)
            {
                stoneList.Add(new Stone(186, 40 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 5; i++)
            {
                stoneList.Add(new Stone(259, 40 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 2; i++)
            {
                stoneList.Add(new Stone(332, 40 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 5; i++)
            {
                stoneList.Add(new Stone(405, 40 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 3; i++)
            {
                stoneList.Add(new Stone(478, 40 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 5; i++)
            {
                stoneList.Add(new Stone(551, 40 + 33 * i, new Size(33, 33)));
            }

            for (int i = 0; i < 5; i++)
            {
                stoneList.Add(new Stone(624, 40 + 33 * i, new Size(33, 33)));
            }
        }
    }
}
