﻿using System.Drawing;
using System.Collections.Generic;
using ClassLibrary.Models;

namespace ClassLibrary.Statics
{
    public static class CreateRiver
    {
        private static List<River> riverList = new List<River>();

        public static List<River> RiverCreate()
        {
            riverList.Add(new River(73, 100, new Size(40, 30)));
            riverList.Add(new River(405, 206, new Size(33, 44)));
            riverList.Add(new River(365, 365, new Size(40, 30)));
            riverList.Add(new River(40, 206, new Size(33, 44)));
            riverList.Add(new River(551, 206, new Size(108, 44)));
            riverList.Add(new River(584, 176, new Size(40, 30)));
            riverList.Add(new River(584, 250, new Size(40, 30)));
            riverList.Add(new River(185, 254, new Size(35, 65)));

            return riverList;
        }
    }
}
