﻿using System.Drawing;
using System.Collections.Generic;
using ClassLibrary.Models;

namespace ClassLibrary.Statics
{
    public static class IronWallCreate
    {
        private static List<IronWall> ironWallList = new List<IronWall>();

        public static List<IronWall> CreateIronWall()
        {
            ironWallList.Add(new IronWall(73, 385, new Size(40, 30)));

            ironWallList.Add(new IronWall(292, 385, new Size(40, 30)));

            ironWallList.Add(new IronWall(219, 40, new Size(40, 30)));

            ironWallList.Add(new IronWall(438, 40, new Size(40, 30)));

            ironWallList.Add(new IronWall(511, 316, new Size(40, 30)));

            return ironWallList;
        }
    }
}
