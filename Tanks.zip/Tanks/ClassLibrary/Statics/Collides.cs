﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ClassLibrary.Models;

namespace ClassLibrary
{
    public static class Collides
    {

        //General Collide
        private static bool Collide(int x1, int y1, int r1, int d1, int x2, int y2, int r2, int d2)
        {
            return !(r1 <= x2 || x1 > r2 || d1 <= y2 || y1 > d2);
        }

        private static bool BoxCollides(int[] pos1, int[] size1, int[] pos2, int[] size2)
        {
            return Collide(pos1[0], pos1[1],
                    pos1[0] + size1[0], pos1[1] + size1[1],
                    pos2[0], pos2[1],
                    pos2[0] + size2[0], pos2[1] + size2[1]);
        }

        //Packman Bullet Collide
        public static bool PackmanBulletDestroyStone(PackmanBullet packmanBullet, Stone stone)
        {
            int[] pos1 = { packmanBullet.X, packmanBullet.Y };
            int[] size1 = { packmanBullet.SizePuckmanBullet.Width, packmanBullet.SizePuckmanBullet.Height };

            int[] pos2 = { stone.X, stone.Y };
            int[] size2 = { stone.SizeStone.Width, stone.SizeStone.Height };

            if (BoxCollides(pos1, size1, pos2, size2))
            {
                return true;
            }

            return false;
        }

        public static bool PackmanBulletToGroundIronWall(PackmanBullet packmanBullet, PictureBox picture, List<IronWall> ironWallList)
        {
            int[] pos1 = { packmanBullet.X, packmanBullet.Y };
            int[] size1 = { packmanBullet.SizePuckmanBullet.Width, packmanBullet.SizePuckmanBullet.Height };

            foreach (IronWall ironWall in ironWallList)
            {
                int[] pos2 = { ironWall.X, ironWall.Y };
                int[] size2 = { ironWall.IronWallSize.Width, ironWall.IronWallSize.Height };
                
                if (BoxCollides(pos1, size1, pos2, size2))
                {
                    return true;
                }
            }

            if (pos1[0] < 0 || pos1[0] + size1[0] > picture.Width || pos1[1] < 0 || pos1[1] + size1[1] > picture.Height)
            {
                return true;
            }

            return false;
        }

        public static bool PackmanBulletToTank(Tank tank, PackmanBullet packmanBullet)
        {
            int[] pos = { packmanBullet.X, packmanBullet.Y };
            int[] size = { packmanBullet.SizePuckmanBullet.Width, packmanBullet.SizePuckmanBullet.Height };

            int[] pos2 = { tank.X, tank.Y };
            int[] size2 = { tank.SizeTank.Width, tank.SizeTank.Height };

            if (BoxCollides(pos2, size2, pos, size))
            {
                return true;
            }

            return false;
        }

        //Apple Collide
        public static bool AppleToStoneGround(Apple apple, PictureBox picture, 
            List<Stone> stoneList, List<River> riverList, List<IronWall> ironWallList)
        {
            int[] pos1 = { apple.X, apple.Y };
            int[] size1 = { apple.SizeApple.Width, apple.SizeApple.Height };

            foreach (Stone stone in stoneList)
            {
                int[] pos2 = { stone.X, stone.Y };
                int[] size2 = { stone.SizeStone.Width, stone.SizeStone.Height };

                if (BoxCollides(pos1, size1, pos2, size2))
                {
                    return true;
                }
            }

            foreach (IronWall ironWall in ironWallList)
            {
                int[] pos2 = { ironWall.X, ironWall.Y };
                int[] size2 = { ironWall.IronWallSize.Width, ironWall.IronWallSize.Height };

                if (BoxCollides(pos1, size1, pos2, size2))
                {
                    return true;
                }
            }

            foreach (River river in riverList)
            {
                int[] pos2 = { river.X, river.Y };
                int[] size2 = { river.SizeRiver.Width, river.SizeRiver.Height };

                if (BoxCollides(pos1, size1, pos2, size2))
                {
                    return true;
                }
            }

            if (pos1[0] < 0 || pos1[0] + size1[0] > picture.Width || pos1[1] < 0 || pos1[1] + size1[1] > picture.Height)
            {
                return true;
            }

            return false;
        }

        public static bool AppleTanksApplesPackman(Apple apple, List<Apple> appleList, List<Tank> tankList, Packman packman)
        {
            int[] pos = { apple.X, apple.Y };
            int[] size = { apple.SizeApple.Width, apple.SizeApple.Height };

            foreach (Apple app in appleList)
            {
                int[] pos1 = { app.X, app.Y };
                int[] size1 = { app.SizeApple.Width, app.SizeApple.Height };

                if (BoxCollides(pos1, size1, pos, size) && apple != app)
                {
                    return true;
                }
            }

            foreach (Tank tank in tankList)
            {
                int[] pos1 = { tank.X, tank.Y };
                int[] size1 = { tank.SizeTank.Width, tank.SizeTank.Height };

                if (BoxCollides(pos1, size1, pos, size))
                {
                    return true;
                }
            }

            int[] pos2 = { packman.X, packman.Y };
            int[] size2 = { packman.PackmanSize.Width, packman.PackmanSize.Height };

            if (BoxCollides(pos2, size2, pos, size))
            {
                return true;
            }

            return false;
        }

        //Packman Collide
        public static bool PackmanApple(Apple apple, Packman packman)
        {
            int[] pos = { packman.X, packman.Y };
            int[] size = { packman.PackmanSize.Width, packman.PackmanSize.Height };

            int[] pos1 = { apple.X, apple.Y };
            int[] size1 = { apple.SizeApple.Width, apple.SizeApple.Height };

            if (BoxCollides(pos1, size1, pos, size))
            {
                return true;
            }

            return false;
        }

        public static bool PackmanBulletTank(Packman packman, List<Bullet> bulletList, List<Tank> tankList)
        {
            int[] pos1 = { packman.X, packman.Y };
            int[] size1 = { packman.PackmanSize.Width, packman.PackmanSize.Height };

            foreach (Bullet bullet in bulletList)
            {
                int[] pos2 = { bullet.X, bullet.Y };
                int[] size2 = { bullet.BulletSize.Width, bullet.BulletSize.Height };

                if (BoxCollides(pos1, size1, pos2, size2))
                {
                    return true;
                }
            }

            foreach (Tank tank in tankList)
            {
                int[] pos2 = { tank.X, tank.Y };
                int[] size2 = { tank.SizeTank.Width, tank.SizeTank.Height };

                if (BoxCollides(pos1, size1, pos2, size2))
                {
                    return true;
                }
            }

            return false;
        }

        public static bool PackmanToStoneGround(Packman packman, List<Stone> stoneList, 
            PictureBox picture, List<River> riverList, List<IronWall> ironWallList)
        {
            int[] pos1 = { packman.X, packman.Y };
            int[] size1 = { packman.PackmanSize.Width, packman.PackmanSize.Height };

            foreach (Stone stone in stoneList)
            {
                int[] pos2 = { stone.X, stone.Y };
                int[] size2 = { stone.SizeStone.Width, stone.SizeStone.Height };

                if (BoxCollides(pos1, size1, pos2, size2))
                {
                    return true;
                }
            }

            foreach (IronWall ironWall in ironWallList)
            {
                int[] pos2 = { ironWall.X, ironWall.Y };
                int[] size2 = { ironWall.IronWallSize.Width, ironWall.IronWallSize.Height };

                if (BoxCollides(pos1, size1, pos2, size2))
                {
                    return true;
                }
            }

            foreach (River river in riverList)
            {
                int[] pos2 = { river.X, river.Y };
                int[] size2 = { river.SizeRiver.Width, river.SizeRiver.Height };

                if (BoxCollides(pos1, size1, pos2, size2))
                {
                    return true;
                }
            }

            if (pos1[0] < 0 || pos1[0] + size1[0] > picture.Width || pos1[1] < 0 || pos1[1] + size1[1] > picture.Height)
            {
                return true;
            }

            return false;
        }

        //Tank Collide
        public static bool TankToStone(Tank tank, List<Stone> stoneList, 
            List<River> riverList, PictureBox picture, List<IronWall> ironWallList)
        {
            int[] pos1 = { tank.X, tank.Y };
            int[] size1 = { tank.SizeTank.Width, tank.SizeTank.Height };

            foreach (Stone stone in stoneList)
            {
                int[] pos2 = { stone.X, stone.Y };
                int[] size2 = { stone.SizeStone.Width, stone.SizeStone.Height };

                if (BoxCollides(pos1, size1, pos2, size2))
                {
                    return true;
                }
            }

            foreach (IronWall ironWall in ironWallList)
            {
                int[] pos2 = { ironWall.X, ironWall.Y };
                int[] size2 = { ironWall.IronWallSize.Width, ironWall.IronWallSize.Height };

                if (BoxCollides(pos1, size1, pos2, size2))
                {
                    return true;
                }
            }

            foreach (River river in riverList)
            {
                int[] pos2 = { river.X, river.Y };
                int[] size2 = { river.SizeRiver.Width, river.SizeRiver.Height };

                if (BoxCollides(pos1, size1, pos2, size2))
                {
                    return true;
                }
            }

            if (pos1[0] < 0 || pos1[0] + size1[0] > picture.Width || pos1[1] < 0 || pos1[1] + size1[1] > picture.Height)
            {
                return true;
            }
        

            return false;
        }

        public static bool TanksCollide(Tank tank, List<Tank> tankList)
        {
            int[] pos = { tank.X, tank.Y };
            int[] size = { tank.SizeTank.Width, tank.SizeTank.Height };

            foreach (Tank tnk in tankList)
            {
                int[] pos1 = { tnk.X, tnk.Y };
                int[] size1 = { tnk.SizeTank.Width, tnk.SizeTank.Height };

                if (BoxCollides(pos1, size1, pos, size) && tank != tnk)
                {
                    return true;
                }
            }

            return false;
        }

        //Bullet Collide
        public static bool BulletDestroyStone(Bullet bullet, Stone stone)
        {
            int[] pos1 = { bullet.X, bullet.Y };
            int[] size1 = { bullet.BulletSize.Width, bullet.BulletSize.Height };

            int[] pos2 = { stone.X, stone.Y };
            int[] size2 = { stone.SizeStone.Width, stone.SizeStone.Height };

            if (BoxCollides(pos1, size1, pos2, size2))
            {
                return true;
            }

            return false;
        }

        public static bool BulletGround(Bullet bullet, PictureBox picture, List<IronWall> ironWallList)
        {
            int[] pos1 = { bullet.X, bullet.Y };
            int[] size1 = { bullet.BulletSize.Width, bullet.BulletSize.Height };

            foreach (IronWall ironWall in ironWallList)
            {
                int[] pos2 = { ironWall.X, ironWall.Y };
                int[] size2 = { ironWall.IronWallSize.Width, ironWall.IronWallSize.Height };

                if (BoxCollides(pos1, size1, pos2, size2))
                {
                    return true;
                }
            }

            if (pos1[0] < 0 || pos1[0] + size1[0] > picture.Width || pos1[1] < 0 || pos1[1] + size1[1] > picture.Height)
            {
                return true;
            }

            return false;
        }

        public static bool BulletToTankAndBullet(Bullet bullet, List<Tank> tankList, List<Bullet> bulletList)
        {
            int[] pos = { bullet.X, bullet.Y };
            int[] size = { bullet.BulletSize.Width, bullet.BulletSize.Height };

            foreach (Bullet bul in bulletList)
            {
                int[] pos1 = { bul.X, bul.Y };
                int[] size1 = { bul.BulletSize.Width, bul.BulletSize.Height };

                if (BoxCollides(pos1, size1, pos, size) && bullet != bul)
                {
                    return true;
                }
            }

            foreach (Tank tank in tankList)
            {
                int[] pos1 = { tank.X, tank.Y };
                int[] size1 = { tank.SizeTank.Width, tank.SizeTank.Height };

                if (BoxCollides(pos1, size1, pos, size))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
