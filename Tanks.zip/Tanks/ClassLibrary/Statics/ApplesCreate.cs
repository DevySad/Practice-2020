﻿using System;
using ClassLibrary.Models;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;

namespace ClassLibrary.Statics
{
    public static class ApplesCreate
    {
        private static List<Apple> appleList = new List<Apple>();

        public static List<Apple> CreateApples(List<Tank> tankList, List<Stone> stoneList, Packman packman,
            PictureBox picture, int countApples, List<River> riverList, List<IronWall> ironWallList)
        {
            Random random = new Random();

            Apple apple;

            while (appleList.Count < countApples)
            {
                apple = new Apple(random.Next(50, picture.Width - 50), random.Next(50, picture.Height - 100), new Size(20, 22));

                if (Collides.AppleToStoneGround(apple, picture, stoneList, riverList, ironWallList) 
                    || Collides.AppleTanksApplesPackman(apple, appleList, tankList, packman))
                    continue;

                appleList.Add(apple);
            }

            return appleList;
        }
    }
}
