﻿using System.Drawing;
using System.Collections.Generic;
using System;
using ClassLibrary.Models;
using System.Windows.Forms;

namespace ClassLibrary
{
    public static class CreateTanks
    {
        private static List<Tank> tankList = new List<Tank>();

        public static List<Tank> TanksCreate(int countTanks, PictureBox picture, List<Stone> stoneList, List<River> riverList)
        {
            Random random = new Random();

            Tank tank;

            while (tankList.Count < countTanks)
            {
                tank = new Tank(random.Next(50, picture.Width - 50), random.Next(50, picture.Height - 100), new Size(30, 33), (EnumWay)(random).Next(4));

                if (Collides.TankToStone(tank, stoneList, riverList, picture) || Collides.TanksCollide(tank, tankList))
                {
                    continue;
                }

                tankList.Add(tank);
            }

            return tankList;
        }

    }
}
