﻿using System.Drawing;

namespace ClassLibrary
{
    public class Stone
    {
        public int X
        {
            get; set;
        }

        public int Y
        {
            get; set;
        }

        public Size SizeStone
        {
            get; set;
        }

        public Stone(int x, int y, Size size)
        {
            X = x;
            Y = y;
            SizeStone = size;
        }
    }
}
