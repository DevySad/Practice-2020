﻿using System.Drawing;

namespace ClassLibrary.Models
{
    public class IronWall
    {
        public int X
        {
            get; set;
        }

        public int Y
        {
            get; set;
        }

        public Size IronWallSize
        {
            get; set;
        }

        public IronWall(int x, int y, Size size)
        {
            X = x;
            Y = y;
            IronWallSize = size;
        }
    }
}
