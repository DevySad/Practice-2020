﻿using System.Drawing;

namespace ClassLibrary.Models
{
    public class Explosion
    {
        public int X
        {
            get; set;
        }

        public int Y
        {
            get; set;
        }

        public Size ExplosionSize
        {
            get; set;
        }

        public Explosion(Bullet bullet, Size size)
        {
            X = bullet.X;
            Y = bullet.Y;
            ExplosionSize = size;
        }

        public Explosion(PackmanBullet packmanBullet, Size size)
        {
            X = packmanBullet.X;
            Y = packmanBullet.Y;
            ExplosionSize = size;
        }
    }
}
