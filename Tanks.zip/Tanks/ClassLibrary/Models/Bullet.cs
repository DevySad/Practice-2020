﻿using System;
using System.Drawing;
using System.Linq;

namespace ClassLibrary.Models
{
    public class Bullet
    {
        public int X
        {
            get; set;
        }

        public int Y
        {
            get; set;
        }

        public Size BulletSize
        {
            get; set;
        }

        public EnumWay Way
        {
            get; set;
        }

        public Bullet(Tank tank, Size size)
        {
            BulletSize = size;
            Way = tank.Way;

            switch(tank.Way)
            {
                case EnumWay.UP:
                    {
                        X = tank.X + 5;
                        Y = tank.Y - 6;
                        break;
                    }
                case EnumWay.DOWN:
                    {
                        X = tank.X + 5;
                        Y = tank.Y + tank.SizeTank.Height;
                        break;
                    }
                case EnumWay.RIGHT:
                    {
                        X = tank.X + tank.SizeTank.Width;
                        Y = tank.Y + 9;
                        break;
                    }
                case EnumWay.LEFT:
                    {
                        X = tank.X - 7;
                        Y = tank.Y + 9;
                        break;
                    }
            }
        }
    }
}
