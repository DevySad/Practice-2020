﻿using System.Drawing;

namespace ClassLibrary.Models
{
    public class Apple
    {
        public int X
        {
            get; set;
        }

        public int Y
        {
            get; set;
        }

        public Size SizeApple
        {
            get; set;
        }

        public Apple(int x, int y, Size size)
        {
            X = x;
            Y = y;
            SizeApple = size;
        }
    }
}
