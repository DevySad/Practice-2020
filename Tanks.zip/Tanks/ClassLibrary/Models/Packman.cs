﻿using System.Drawing;

namespace ClassLibrary.Models
{
    public class Packman
    {
        public int X
        {
            get; set;
        }

        public int Y
        {
            get; set;
        }

        public Size PackmanSize
        {
            get; set;
        }

        public EnumWay Way
        {
            get; set;
        }

        public Packman(int x, int y, Size size, EnumWay way)
        {
            X = x;
            Y = y;
            PackmanSize = size;
            Way = way;
        }
    }
}
