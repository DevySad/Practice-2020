﻿using ClassLibrary;
using System;
using System.Drawing;

public class Tank
{
    public int X
    {
        get; set;
    }

    public int Y
    {
        get; set;
    }

    public Size SizeTank
    {
        get; set;
    }

    public EnumWay Way
    {
        get; set;
    }

	public Tank(int x, int y, Size size, EnumWay way)
	{
        X = x;
        Y = y;
        SizeTank = size;
        Way = way;
	}
}
