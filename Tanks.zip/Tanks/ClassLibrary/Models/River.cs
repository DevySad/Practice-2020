﻿using System.Drawing;

namespace ClassLibrary.Models
{
    public class River
    {
        public int X
        {
            get; set;
        }

        public int Y
        {
            get; set;
        }

        public Size SizeRiver
        {
            get; set;
        }

        public River(int x, int y, Size size)
        {
            X = x;
            Y = y;
            SizeRiver = size;
        }
    }
}
