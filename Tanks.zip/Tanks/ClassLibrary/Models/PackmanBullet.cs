﻿using System.Drawing;

namespace ClassLibrary.Models
{
    public class PackmanBullet
    {
        public int X
        {
            get; set;
        }

        public int Y
        {
            get; set;
        }

        public Size SizePuckmanBullet
        {
            get; set;
        }

        public EnumWay Way
        {
            get; set;
        }

        public PackmanBullet(Packman packman, Size size)
        {
            SizePuckmanBullet = size;
            Way = packman.Way;

            switch(packman.Way)
            {
                case EnumWay.UP:
                    {
                        X = packman.X + 12;
                        Y = packman.Y - 6;

                        break;
                    }
                case EnumWay.DOWN:
                    {
                        X = packman.X + 12;
                        Y = packman.Y + packman.PackmanSize.Height;

                        break;
                    }
                case EnumWay.RIGHT:
                    {
                        X = packman.X + packman.PackmanSize.Width;
                        Y = packman.Y - 10;

                        break;
                    }
                case EnumWay.LEFT:
                    {
                        X = packman.X - 7;
                        Y = packman.Y - 10;

                        break;
                    }
            }
        }
    }
}
