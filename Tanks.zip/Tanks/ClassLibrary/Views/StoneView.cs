﻿using System.Drawing;

namespace ClassLibrary
{
    public class StoneView
    {
        public Graphics graphicsStone;

        public StoneView(Stone stone, Bitmap bitmap)
        {
            DrawStone(stone, bitmap);
        }

        public void DrawStone(Stone stone, Bitmap bitmap)
        {
            graphicsStone = Graphics.FromImage(bitmap);

            graphicsStone.DrawImage(Image.FromFile(@"..\..\..\img\stone.png"), new Rectangle(new Point(stone.X, stone.Y), stone.SizeStone));
        }
    }
}
