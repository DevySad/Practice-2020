﻿using System.Drawing;
using ClassLibrary.Models;

namespace ClassLibrary.Views
{
    public class PackmanBulletView
    {
        public Graphics graphicsPackmanBullet;

        public PackmanBulletView(PackmanBullet bullet, Bitmap bitmap)
        {
            CreatePackmanBullet(bullet, bitmap);
        }

        void CreatePackmanBullet(PackmanBullet bullet, Bitmap bitmap)
        {
            graphicsPackmanBullet = Graphics.FromImage(bitmap);

            graphicsPackmanBullet.DrawImage(Image.FromFile(@"..\..\..\img\bullet-packman.png"), new Rectangle(new Point(bullet.X, bullet.Y), bullet.SizePuckmanBullet));
        }
    }
}
