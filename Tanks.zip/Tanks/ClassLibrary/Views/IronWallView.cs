﻿using System.Drawing;
using ClassLibrary.Models;

namespace ClassLibrary.Views
{
    public class IronWallView
    {
        public Graphics graphicsIronWall;

        public IronWallView(IronWall ironWall, Bitmap bitmap)
        {
            DrawIronWall(ironWall, bitmap);
        }

        public void DrawIronWall(IronWall ironwall, Bitmap bitmap)
        {
            graphicsIronWall = Graphics.FromImage(bitmap);

            graphicsIronWall.DrawImage(Image.FromFile(@"..\..\..\img\iron-wall.png"), new Rectangle(new Point(ironwall.X, ironwall.Y), ironwall.IronWallSize));
        }
    }
}
