﻿using System.Drawing;
using ClassLibrary.Models;

namespace ClassLibrary.Views
{
    public class RiverView
    {
        public Graphics graphicsRiver;

        public RiverView(River river, Bitmap bitmap)
        {
            DrawRiver(river, bitmap);
        }

        public void DrawRiver(River river, Bitmap bitmap)
        {
            graphicsRiver = Graphics.FromImage(bitmap);

            graphicsRiver.DrawImage(Image.FromFile(@"..\..\..\img\river.png"), new Rectangle(new Point(river.X, river.Y), river.SizeRiver));
        }
    }
}
