﻿using System.Drawing;
using ClassLibrary.Models;

namespace ClassLibrary.Views
{
    public class AppleView
    {
        public Graphics graphicsApple;

        public AppleView(Apple apple, Bitmap bitmap)
        {
            CreateApple(apple, bitmap);
        }

        void CreateApple(Apple apple, Bitmap bitmap)
        {
            graphicsApple = Graphics.FromImage(bitmap);

            graphicsApple.DrawImage(Image.FromFile(@"..\..\..\img\apple.png"), new Rectangle(new Point(apple.X, apple.Y), apple.SizeApple));
        }
    }
}
