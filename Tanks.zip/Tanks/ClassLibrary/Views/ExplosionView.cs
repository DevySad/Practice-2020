﻿using System.Drawing;
using ClassLibrary.Models;

namespace ClassLibrary.Views
{
    public class ExplosionView
    {
        public Graphics graphicsExplosion;

        public ExplosionView(Explosion explosion, Bitmap bitmap)
        {
            DrawExplosion(explosion, bitmap);
        }

        public void DrawExplosion(Explosion explosion, Bitmap bitmap)
        {
            graphicsExplosion = Graphics.FromImage(bitmap);

            graphicsExplosion.DrawImage(Image.FromFile(@"..\..\..\img\explosion.png"), new Rectangle(new Point(explosion.X, explosion.Y), explosion.ExplosionSize));
        }
    }
}
