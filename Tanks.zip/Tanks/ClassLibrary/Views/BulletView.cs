﻿using System.Drawing;
using ClassLibrary.Models;

namespace ClassLibrary.Views
{
    public class BulletView
    {
        public Graphics graphicsBullet;

        public BulletView(Bullet bullet, Bitmap bitmap)
        {
            CreateBullet(bullet, bitmap);
        }

        void CreateBullet(Bullet bullet, Bitmap bitmap)
        {
            graphicsBullet = Graphics.FromImage(bitmap);

            graphicsBullet.DrawImage(Image.FromFile(@"..\..\..\img\bullet-tank.png"), new Rectangle(new Point(bullet.X, bullet.Y), bullet.BulletSize));
        }
    }   
}
