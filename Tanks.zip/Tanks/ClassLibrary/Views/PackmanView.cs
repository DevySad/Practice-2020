﻿using System.Drawing;
using ClassLibrary.Models;

namespace ClassLibrary.Views
{
    public class PackmanView
    {
        public Graphics graphicsPackman;

        public PackmanView(Packman packman, Bitmap bitmap)
        {
            CreatePackman(packman, bitmap);
        }

        void CreatePackman(Packman packman, Bitmap bitmap)
        {
            graphicsPackman = Graphics.FromImage(bitmap);

            switch (packman.Way)
            {
                case EnumWay.UP:
                    graphicsPackman.DrawImage(Image.FromFile(@"..\..\..\img\packman-up.png"), new Rectangle(new Point(packman.X, packman.Y), packman.PackmanSize));
                    break;
                case EnumWay.DOWN:
                    graphicsPackman.DrawImage(Image.FromFile(@"..\..\..\img\packman-down.png"), new Rectangle(new Point(packman.X, packman.Y), packman.PackmanSize));
                    break;
                case EnumWay.RIGHT:
                    graphicsPackman.DrawImage(Image.FromFile(@"..\..\..\img\packman-right.png"), new Rectangle(new Point(packman.X, packman.Y), packman.PackmanSize));
                    break;
                case EnumWay.LEFT:
                    graphicsPackman.DrawImage(Image.FromFile(@"..\..\..\img\packman-left.png"), new Rectangle(new Point(packman.X, packman.Y), packman.PackmanSize));
                    break;
            }

        }
    }
}
