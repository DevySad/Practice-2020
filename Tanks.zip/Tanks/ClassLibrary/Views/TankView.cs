﻿using System;
using System.Drawing;

public class TankView
{
    public Graphics graphicsTank;

    public TankView(Tank tank, Bitmap bitmap)
    {
        CreateTank(tank, bitmap);
    }

    void CreateTank(Tank tank, Bitmap bitmap)
    {
        graphicsTank = Graphics.FromImage(bitmap);

        graphicsTank.DrawImage(Image.FromFile(@"..\..\..\img\tank.png"), new Rectangle(new Point(tank.X, tank.Y), tank.SizeTank));
    }
    
}
