﻿using System;
using System.Drawing;
using ClassLibrary;

public class TankView
{
    public Graphics graphicsTank;

    public TankView(Tank tank, Bitmap bitmap)
    {
        CreateTank(tank, bitmap);
    }

    void CreateTank(Tank tank, Bitmap bitmap)
    {
        graphicsTank = Graphics.FromImage(bitmap);

        switch (tank.Way)
        {
            case EnumWay.UP:
                graphicsTank.DrawImage(Image.FromFile(@"..\..\..\img\tank-up.png"), new Rectangle(new Point(tank.X, tank.Y), tank.SizeTank));
                break;
            case EnumWay.DOWN:
                graphicsTank.DrawImage(Image.FromFile(@"..\..\..\img\tank-down.png"), new Rectangle(new Point(tank.X, tank.Y), tank.SizeTank));
                break;
            case EnumWay.RIGHT:
                graphicsTank.DrawImage(Image.FromFile(@"..\..\..\img\tank-right.png"), new Rectangle(new Point(tank.X, tank.Y), tank.SizeTank));
                break;
            case EnumWay.LEFT:
                graphicsTank.DrawImage(Image.FromFile(@"..\..\..\img\tank-left.png"), new Rectangle(new Point(tank.X, tank.Y), tank.SizeTank));
                break;
        }
     
    }   
}
