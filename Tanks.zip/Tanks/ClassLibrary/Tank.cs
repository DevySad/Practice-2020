﻿using System;
using System.Drawing;

public class Tank
{
    public int X
    {
        get; set;
    }

    public int Y
    {
        get; set;
    }

    public Size SizeTank
    {
        get; set;
    }

	public Tank(int x, int y, Size size)
	{
        X = x;
        Y = y;
        SizeTank = size;
	}
}
