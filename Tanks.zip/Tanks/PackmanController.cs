﻿using System;

public class PackmanController
{
	public PackmanController()
	{
	}
}
